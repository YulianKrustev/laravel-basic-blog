-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2023 at 02:31 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basic_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Laptops'),
(2, 'Tablets'),
(3, 'Mobile Phones'),
(4, 'Keyboards'),
(5, 'Mouses'),
(6, 'Routers'),
(7, 'Monitors');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `content`, `created_at`, `updated_at`) VALUES
(1, 49, 1, 'asdsad', '2023-09-01 11:22:33', '2023-09-01 11:22:33'),
(2, 49, 1, 'adfadsf', '2023-09-01 11:42:32', '2023-09-01 11:42:32'),
(3, 49, 1, 'test test 1', '2023-09-01 12:05:05', '2023-09-01 12:05:05');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `message`, `created_at`, `updated_at`) VALUES
(1, 'test', 'juliankrustev2018@gmail.com', '0888951429', 'asdsads', '2023-08-31 10:34:23', '2023-08-31 10:34:23'),
(2, 'asdas', 'juliankrustev2018@gmail.com', '0888951429', 'sadsad', '2023-08-31 11:21:20', '2023-08-31 11:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 49, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_08_29_192437_create_contacts_table', 1),
(6, '2023_08_30_152621_create_categories_table', 1),
(7, '2023_08_30_155142_create_posts_table', 1),
(8, '2023_09_01_141519_create_comments_table', 2),
(9, '2023_09_01_145028_create_likes_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('juliankrustev2018@gmail.com', '$2y$10$lJF8KBKBfXhs7jcGYuO9kePJytRtBUQA3F5PQycGwmWJpWp0ErBgK', '2023-08-31 16:26:50');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `image`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(29, 'Acer Aspire 7 (A715-76G)', '<p>If you need an all-purpose laptop that lacks the typical gaming design of modern machines, you don&rsquo;t have a lot of options. Especially if you don&rsquo;t want to pay a whole fortune for an office notebook that is going to be used for playing some games for an hour or two after work.</p>\r\n<p>In this scenario, the Acer Aspire 7 (A715-76G) is one of the possible solutions. The laptop doesn&rsquo;t cost much and it offers Intel Alder Lake-H CPU options and optional RTX 3000 and RTX 2000 dGPU variants. On top of that, you can configure it with a high refresh rate display and this will transform it into a pretty decent gaming device (at least on paper).</p>\r\n<p>Given the price tag of this machine, it doesn&rsquo;t bring all the bangs and whistles of today&rsquo;s top-end devices, but that&rsquo;s normal. The notebook brings to the table extras like a backlit keyboard, Wi-Fi 6E, and Thunderbolt 4 which can be important for a lot of future buyers.</p>\r\n<p>At least for us, the thing that matters the most is how the cooling will handle the thirsty H-series CPU alongside a dedicated video card. We will see the end result very soon so stay tuned!</p>', 'posts_images/1775826038948111.jpg', 1, 1, '2023-09-01 09:14:43', NULL),
(30, 'Dell Vostro 15 3530', '<p>Thanks to the technology evolving, a lot of the modern mid-range and low-range devices can be used for both office and home tasks. Nowadays, even some inexpensive CPUs have at least six cores or even more which is great for the regular user. In this article, we&rsquo;ll show you a laptop that is suitable for normal daily tasks and for office usage as well.</p>\r\n<p>The notebook is called Dell Vostro 15 3530 and it comes with 13th Gen Intel Raptor Lake U-series CPU options that can be pretty efficient if the manufacturer optimization is done in the right way. Some of the important extras are optional &ndash; like the backlit keyboard and the fingerprint reader. The base display option is a prehistoric 768p TN display and this sounds so outdated in 2023. You have to avoid this one by any means necessary because the optional 120Hz IPS panel should be the way to go for most users if money isn&rsquo;t a problem.</p>\r\n<p>We can also spot an NVIDIA dGPU option in the specs and that&rsquo;s kind of a surprise given the low price tag of the device. We didn&rsquo;t find such a laptop but we bought one with the most powerful CPU option in order to torture the cooling solution. This is the weak spot of some Dell devices like the so let&rsquo;s see if this one can surprise us with a better cooling system than its more premium sibling.</p>', 'posts_images/1775826136449287.jpg', 1, 1, '2023-09-01 09:16:16', NULL),
(31, 'Lenovo IdeaPad Slim 3', '<p>Budget laptops are very important for every manufacturer because occasionally they are the backbone of some companies when it comes to profit. Today we are going to show you the Lenovo IdeaPad Slim 3 (14&Prime; AMD, Gen 8) &ndash; an inexpensive machine that can be configured with efficient (and refreshed) AMD Barcelo-U chips from the 7000 series.</p>\r\n<p>We have a dedicated article about the more premium sibling of this laptop &ndash; the&nbsp;<a href=\"https://laptopmedia.com/review/lenovo-ideapad-slim-5-14-amd-gen-8-review-cool-quiet-and-powerful/\" target=\"_blank\" rel=\"noopener\">Lenovo IdeaPad Slim 5 (14&Prime; AMD, Gen 8)</a>&nbsp;and we also reviewed the 16-inch iteration of the device that is sitting in front of us &ndash; the&nbsp;<a href=\"https://laptopmedia.com/review/lenovo-ideapad-slim-3-16-2023-review-affordable-and-super-efficient/\" target=\"_blank\" rel=\"noopener\">Lenovo IdeaPad Slim 3 (16&Prime;, 2023)</a>. The Slim 5 machine has a metal chassis and a bit more potent cooling while the bigger Slim 3 16&Prime; boasts a larger body. So our not-so-pricey 14&Prime; notebook has to prove to us that it can deal with the competition from the same brand and that it can handle the AMD Zen 3+ chips regardless of its low price.</p>\r\n<p>The device can be configured with a good amount of optional features such as Wi-Fi 6, a backlit keyboard, a fingerprint reader, and a 1080p Web camera. Ergo, if you want to supercharge the laptop in terms of extras, you have to pay a bit more. Specs-wise, this gadget looks like a good deal but we&rsquo;ll torture it for a few hours before making a final conclusion.</p>', 'posts_images/1775826236565136.jpg', 1, 1, '2023-09-01 09:17:52', '2023-09-01 09:18:27'),
(40, 'Lenovo Yoga Book 9 (13IRU8)', '<p>The 2-in-1 laptops are meant for people who want to be different and own a multipurpose device that can transform into a tablet within a second. Portability, power, and battery life are also important for buyers because very often, these devices are used for office or content creation needs.</p>\r\n<p>If you want to stand out among the other people around you (and if money isn&rsquo;t a problem) the Lenovo Yoga Book 9 (13IRU8) is a device that has a unique visual appearance thanks to its two OLED touchscreen displays for productivity boost. Yes, you heard it right, this machine lacks a built-in keyboard and touchpad but you can use them virtually on the second panel if you want. Lenovo has also provided some additional gadgets in the box if you prefer to operate with this extraordinary machine as a normal laptop but we&rsquo;ll talk about this in a minute.</p>\r\n<p>Lenovo Yoga Book 9 (13IRU8) can be used by everyone &ndash; people in the office will value its multitasking abilities thanks to the two touch panels, you can also have fun playing games on the main screen and watch videos on the second panel (or you can also use both screens for gaming which is super cool), and daily tasks such as watching videos and checking your email look way more fun when you can utilize both screens at the same time for these home &ldquo;duties&rdquo;.</p>\r\n<p>Hardware-wise, the device relies on the Raptor Lake-U series CPUs which is the right choice for a transformer like this one (well, a 28W P processor is too much in terms of heat dissipation for a notebook that has a display above its motherboard). The gadget is also configured with a fast LPDDR5x RAM and it has a Gen 4 SSD under the hood. We tested the performance of the laptop and its features, and now we are impatient to share with you all the info we gathered. Let&rsquo;s go!</p>', 'posts_images/1775829192454087.jpg', 1, 1, '2023-09-01 10:04:51', NULL),
(41, 'Lenovo IdeaPad Slim 5 (14 AMD, Gen 8)', '<p>The thinner laptops are getting more and more popular among modern users. The high demand for such devices is clearly visible &ndash; people want potent machines that are portable at the same time and most manufacturers have numerous devices that are corresponding to this criteria.</p>\r\n<p>Lenovo is one of the brands that offer plenty of notebooks with thin profiles that are branded &ldquo;Slim&rdquo;. This category of notebooks contains devices for any kind of usage &ndash; gaming, office, and regular all-purpose laptops. This time we will show you the Lenovo IdeaPad Slim 5 (14&Prime; AMD, Gen 8) which is a compact 14-incher that can be found with AMD Ryzen 7000U CPUs (these are refreshed Zen 3+ chips). Based on our previous review with Lenovo laptops with the same processors, the performance should be good for the class, if the cooling is adequate.</p>\r\n<p>Because we like to torture our laptops, we got the most powerful AMD Ryzen 7 model because we want to see how good the cooling system is. This is an inexpensive device but boasts features like Wi-Fi 6E, Bluetooth 5.1, and three display options (one of them is an OLED panel) so at least on paper, this sounds like a fair deal given the end price which is on the low side.</p>\r\n<p>We already reviewed the&nbsp;<a href=\"https://laptopmedia.com/review/lenovo-ideapad-slim-5-16-2023-review-a-better-slightly-more-expensive-version-of-the-ideapad-slim-3/\" target=\"_blank\" rel=\"noopener\">Lenovo IdeaPad Slim 5 (16&Prime;, 2023)</a>&nbsp;and that&rsquo;s the bigger sibling of the laptop that we are showing you today. We are curious to see if the 14-incher model can keep up with its 16-inch &ldquo;cousin&rdquo; when it comes to pure performance. Let&rsquo;s find out the answer together.</p>\r\n<p>You can check the prices and configurations in our Specs System:&nbsp;<a href=\"https://laptopmedia.com/series/lenovo-ideapad-slim-5-14-2023/\" target=\"_blank\" rel=\"noopener\">https://laptopmedia.com/series/lenovo-ideapad-slim-5-14-2023/</a></p>', 'posts_images/1775829989985734.jpg', 1, 1, '2023-09-01 10:17:31', NULL),
(42, 'Lenovo Smart Tab M10 HD (2nd Gen)', '<p>Finding the right tablet shouldn&rsquo;t be a chore. Inexpensive tablets are plentiful, though we certainly don&rsquo;t recommend all of them. Moreover, finding a tablet that works well for kids can be a hassle. Enter the Lenovo Smart Tab M10 HD, which is a 10-inch Android tablet with a dedicated kids mode and Google Assistant display to boot. Find out if it&rsquo;s the right cheap tablet for you in this Lenovo Smart Tab M10 HD review.</p>', 'posts_images/1775830197218277.jpg', 1, 2, '2023-09-01 10:20:49', NULL),
(43, 'Lenovo Tab M10 Plus (3rd Gen)', '<p>Lenovo is back with a budget tablet, which looks to be a great choice for the masses. We took the Tab M10 Plus for a spin, and we were pleased with the overall performance considering the review version we have (4GB of RAM), and its price point.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Design &amp; Features&nbsp;</strong></p>\r\n<p>The Lenovo Tab M10 Plus is packed with a 10.61in IPS display with 2K resolution, slim bezels at an 85% screen-to-body ratio, and a brightness of 400 nits. Additionally, the Tab M10 Plus comes with a quad speakers and Dolby Atmos support, making it ideal for streaming music and watching tv shows and movies.&nbsp;</p>\r\n<div class=\"inline-single-ad ad_single_index alignfull\">&nbsp;</div>\r\n<p>The Tab M10 Plus has dimensions of 7.45 mm in height and 465 grams in weight, and feature an 8-megapixel cameras on both the front and rear.&nbsp;</p>', 'posts_images/1775830288168651.jpg', 1, 2, '2023-09-01 10:22:16', NULL),
(44, 'Samsung Galaxy Tab S8', '<p>Tablets in Samsung\'s Galaxy Tab S8 series are Android\'s answer to Apple\'s pro-level iPads, and the best devices for professional creative work on the platform. The Tab S8 is the smallest model in the lineup, but it still has plenty of power power, sports a beautiful 11-inch screen, and comes with Samsung\'s excellent S Pen stylus. We\'re also fans of Samsung\'s productivity-focused Dex mode, which bridges the gap between Android and Chrome OS. But at $699.99, the Galaxy Tab S8 costs more than comparable iPads and Windows tablets, while offering fewer pro apps than those devices. Until Android\'s tablet experience catches up to the competition, all high-end&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-android-tablets\" target=\"_self\">Android tablets</a>, no matter how impressive the hardware, remain at a disadvantage.</p>', 'posts_images/1775830379453049.jpg', 1, 2, '2023-09-01 10:23:43', NULL),
(45, 'Samsung Galaxy Tab S7', '<p>The Samsung Galaxy Tab S7+ is the most capable Android productivity tablet on the market. In addition to being the first to support 5G connectivity, it&rsquo;s also a performance powerhouse that can handle multitasking with ease.&nbsp;Though its starting price of $849&mdash;which doesn\'t include 5G capability or the carrier subscription to use it, nor the Book Cover Keyboard Case&mdash;looks steep, it\'s one of the few viable laptop alternatives on the market, especially if you often commute or travel and don\'t want to bother with a hotspot. With impressive features, incredible performance, and all-day battery life, it\'s the&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-android-tablets\" target=\"_self\">best Android tablet</a> you can buy right now, and wins our Editors\' Choice award.</p>', 'posts_images/1775830422617824.jpg', 1, 2, '2023-09-01 10:24:24', NULL),
(46, 'Samsung Galaxy Z Flip 5', '<p>The $999.99 Samsung Galaxy Z Flip 5 is the smaller&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-phones\" target=\"_self\">phone</a>&nbsp;in Samsung\'s lineup of foldables, which also includes the $1,799.99&nbsp;<a href=\"https://www.pcmag.com/news/hands-on-with-samsungs-fully-foldable-galaxy-z-flip-5-and-z-fold-5\" target=\"_self\">Galaxy Z Fold 5</a>. Where the Z Fold 5 takes a normal-size phone and expands it into productivity-empowering&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-tablets\" target=\"_self\">tablet</a>&nbsp;territory, the Z Flip 5 is about making a large screen smaller, more fun, and easier to stuff into your pocket. The Fold opens like a book and is intended for power users, while the Flip bends at the waist and is aimed at casual users who want a stylish, powerful handset that flips closed for maximum portability.</p>\r\n<p>In its fifth generation, the Flip 5 makes only small improvements over the&nbsp;<a href=\"https://www.pcmag.com/reviews/samsung-galaxy-z-flip-4\" target=\"_self\">Z Flip 4</a>, such as modest spec bumps and the ability to fold completely flat (like the $999.99&nbsp;<a href=\"https://www.pcmag.com/reviews/motorola-razr-plus-2023\" target=\"_self\">Motorola Razr+</a>). The new hardware is as tough as it is beautiful with an IPX8 rating and&nbsp;<a href=\"https://www.pcmag.com/news/cornings-gorilla-glass-victus-2-will-feature-on-samsungs-galaxy-s23-series\" target=\"_self\">Gorilla Glass Victus 2</a>, plus Samsung says the new hinge is more durable than before. Most significantly, Samsung increased the size of the outer display to expand its usability. Samsung and Motorola take wildly different approaches to how the front screen is used, and that is what differentiates these phones the most. Depending on what you want in a modern-day flip phone, either the Z Flip 5 or the Razr+ can serve you quite well.</p>', 'posts_images/1775830487303825.jpg', 1, 3, '2023-09-01 10:25:26', NULL),
(47, 'Samsung Galaxy Z Fold 5', '<p>The $1,799.99 Samsung Galaxy Z Fold 5 is the larger foldable in Samsung\'s line, which also includes the $999.99&nbsp;<a href=\"https://www.pcmag.com/reviews/samsung-galaxy-z-flip-5\" target=\"_self\">Galaxy Z Flip 5</a>. Whereas the Flip 5 puts a big 6.7-inch display into a compact package that folds in half like a clamshell, the Fold 5 is a standard Android slab&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-phones\" target=\"_self\">phone</a>&nbsp;that opens up like a book into a 7.6-inch&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-tablets\" target=\"_self\">tablet</a>. Upgrades over the&nbsp;<a href=\"https://www.pcmag.com/reviews/samsung-galaxy-z-fold-4\" target=\"_self\">Z Fold 4</a> include a smaller, lighter chassis that folds completely flat thanks to a re-engineered hinge, upgraded Gorilla Glass, and top-of-the-line specs. If you were waiting for the Z Fold series to fully work out its kinks, the Z Fold 5 is the phone you\'ve been waiting for. It\'s worth the high price for power users and earns our Editors\' Choice award for folding phones.</p>', 'posts_images/1775830534584060.jpg', 1, 3, '2023-09-01 10:26:11', NULL),
(48, 'Google Pixel Fold', '<p>While Google has been developing Android for foldable phones for years, the $1,799 Pixel Fold is the company\'s first foray into the market. The Pixel Fold opens and closes like a book, just like its closest competitor, the&nbsp;<a href=\"https://www.pcmag.com/reviews/samsung-galaxy-z-fold-4\" target=\"_self\">Samsung Galaxy Z Fold 4</a>&nbsp;(starting at $1,799.99), but there are some key differences. Apart from the moderately different shapes of the two&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-phones\" target=\"_self\">phones</a>, the Galaxy Z Fold 4 is packed with productivity-enhancing software, which is where the Pixel Fold falls flat: You\'re limited to two open apps on the inner screen, you can\'t customize the inner and outer displays separately, there\'s no stylus support, and there\'s no desktop mode. Despite the Pixel\'s appealing hardware and capable cameras, the Galaxy Z Fold 4 remains our top pick for folding phones&mdash;at least until the Z Fold 5 arrives later this summer.</p>', 'posts_images/1775830585554469.jpg', 1, 3, '2023-09-01 10:26:59', NULL),
(49, 'TP-Link Archer AX5400 Pro', '<p>Designed for midsized houses and moderate budgets, the TP-Link Archer AX5400 Pro ($199.99) is a dual-band&nbsp;<a href=\"https://www.pcmag.com/picks/the-best-wi-fi-6-routers\" target=\"_self\">Wi-Fi 6 router</a>&nbsp;that offers a handful of welcome features, including multi-gig WAN/LAN connectivity, free HomeShield software, and mesh capabilities. The router performed admirably in our throughput and signal-strength tests, but its file-transfer scores were just average. The Archer is a solid value among mainstream routers, but our Editors\' Choice award winner the&nbsp;<a href=\"https://www.pcmag.com/reviews/synology-wrx560\" target=\"_self\">Synology WRX560</a> offers many of the same features and better overall performance for just a few dollars more.</p>', 'posts_images/1775830656226547.jpg', 1, 6, '2023-09-01 10:28:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Юлиан Кръстев', 'juliankrustev2018@gmail.com', NULL, '$2y$10$wI9i5XvNJ38y4j7hH1f57uw5w1gGcejJX425ftXn43iBBJr.Ytu6.', 'CskvaBNVAGYz7xAbpL6adAMeXnOAVXFo53b4oXhxuZG1wjb8HIhIF3QpZ06f', '2023-08-31 02:52:16', '2023-08-31 17:22:35'),
(2, 'Test', 'test@gmail.com', NULL, '$2y$10$vRQ3./9iueGahm5Z0LCQf.KFUV4MJxUduTTCtLJqJCVaGIfFrznGO', NULL, '2023-08-31 15:03:02', '2023-08-31 15:03:02'),
(3, 'test123', 'email@abv.bg', NULL, '$2y$10$eusNetjABiad7aon60Fy0u5kPFtn8jXu5nlASweMwpf0ehZrS7rwu', NULL, '2023-08-31 16:15:06', '2023-08-31 16:15:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_post_id_foreign` (`post_id`),
  ADD KEY `comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `likes_post_id_foreign` (`post_id`),
  ADD KEY `likes_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_user_id_foreign` (`user_id`),
  ADD KEY `posts_category_id_foreign` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
